#!/bin/bash

#global vars
region="us-east-1"
availability_zone="us-east-1a"
declare -A ami_ids
#ubuntu AMIs
ami_ids[ap-northeast-1]=ami-bebda6bf
ami_ids[ap-southeast-1]=ami-bac1ebe8
ami_ids[ap-southeast-2]=ami-e3eb9fd9
ami_ids[eu-central-1]=ami-b2b587af
ami_ids[eu-west-1]=ami-f1810f86
ami_ids[sa-east-1]=ami-53f14e4e
ami_ids[us-east-1]=ami-4c7a3924
ami_ids[us-west-1]=ami-84bba3c1
ami_ids[us-west-2]=ami-17471c27
ami_user=ubuntu
backup_device=/dev/xvdx
backup_partition=/dev/xvdx1

max_timeout_tries=15

# print debug statement if environment variable set
debug()
{
    if [ "$EC2_BACKUP_VERBOSE" != "" ]; then
        echo $*
    fi
}

# terminate instance if it has been created
# delete volume by default, pass false to not delete
# param: deleteVolume (true)
cleanup()
{
    if [ "$instance_id" != "" ]; then
        debug "Terminating instance $instance_id."
        ec2-terminate-instances $instance_id
        # TODO: perhaps check if above command returns non-zero
    fi
    # delete volume by default
    if [[ "$1" != "false" && "$new_volume_created" != "" && "$volume_id" != "" ]]; then
        debug "Detaching and deleting volume $volume_id"
        ec2-detach-volume $volume_id --force
        while [ $(ec2-describe-volumes --region $region | grep $volume_id | head -1 | awk '{print $5}') != "available" ]
        do
            debug "Waiting for volume to become available after detachment."
        done
        ec2-delete-volume $volume_id
    fi
}

check_for_failure()
{
    if [ $? -ne 0 ]; then
        echo $1
        cleanup $2
        exit 1
    fi
}

wait_for_ssh()
{
    debug "Waiting for AWS instance to allow SSH connection."
    #http://serverfault.com/questions/388184/waiting-until-tcp-socket-is-available-in-bash
    local tries=0
    nc -z -w 10 $instance_host 22   #22 is ssh port
    while [[ $? -ne 0 && $tries -ne $max_timeout_tries ]]
    do
        ((tries++))
        debug "timeout: try $tries"
        sleep 10
        nc -z -w 10 $instance_host 22
    done

    if [ $tries -eq $max_timeout_tries ]; then
        cleanup
        echo "Unable to ssh to AWS instance."
        exit 1
    fi
}

print_help()
{
    echo "usage:" $0 "[-h] [-m method] [-v volume-id] dir"
}

find_dir()
{
    for arg in "$@"
    do
        if [[ $arg =~ ^- ]]; then
            #current arg is a flag
            local prev_flag=$arg
        else
            if [ "$prev_flag" == "" ]; then
                #current arg is not a flag and prev arg wasn't a flag
                #this must be the dir
                dir=$arg
                break
            else
                #current arg is not a flag but prev arg was a flag
                #this arg is arg to prev flag so unset prev_flag
                local prev_flag=
            fi
        fi
    done
}

method=$(echo $* | grep -P -o '(?<=-m )[^\s]+')
volume_id=$(echo $* | grep -P -o '(?<=-v )[^\s]+')
help=$(echo $* | grep -o '\-h')
dir=

find_dir "$@"

if [ "$help" = "-h" ]; then
    print_help
    exit 0
fi

if [ "$method" = "" ]; then
    method="dd"
fi

if [[ "$method" != "dd"  && "$method" != "rsync" ]]; then
    echo "Invalid method specified. Valid methods are 'dd' and 'rsync'."
    exit 1
fi

if [ "$dir" = "" ]; then
    echo "No directory specified."
    exit 1
fi

# check if directory exists
if [ ! -d "$dir" ]; then
    echo "Specified directory does not exist."
    exit 1
fi

debug "method:" $method
debug "volume-id:" $volume_id
debug "dir:" $dir

#---------program starts--------------

debug "Getting list of available regions."
available_regions=( $(ec2-describe-regions | awk '{print $2}') )
if [[ $? -ne 0 || ${#available_regions[@]} -eq 0 ]]; then
    cleanup
    echo "No available regions. Please ensure you have set up your environment variables for AWS."
    exit 1
fi

debug "Available regions:" ${available_regions[@]}

# size of the directory we will be backing up
debug "Calculating size of specified directory."
dir_size=$(du -c -BG $dir | grep total | awk '{print $1}' | grep -o ".*[^G]")
vol_size=$(($dir_size * 2))
debug "Directory size is $dir_size"
debug "Volume size will be $vol_size"

# create the new volume
if [ "$volume_id" = "" ]; then
    debug "Creating new volume on AWS."
    output=$(ec2-create-volume -s $vol_size -z $availability_zone)
    check_for_failure "Unable to create volume on AWS."
    volume_id=$(echo $output | awk '{print $2}')
    new_volume_created=true
    debug "Created new volume $volume_id"
else
    # check if volume_id actually exists
    debug "Checking if specified volume-id $volume_id exists on AWS."
    for r in "${available_regions[@]}"
    do
        debug "Checking region $r."
        if [[ $(ec2-describe-volumes --region $r | grep -o $volume_id) == $volume_id ]]; then
            debug "Volume $volume_id in region $r"
            region=$r
            break
        fi
    done
fi

debug "Getting availability zone from region."
availability_zone=$(ec2-describe-availability-zones --region $region | head -1 | awk '{print $2}')
debug "Availability zone: $availability_zone"

if [ "$availability_zone" == "" ]; then
    echo "No zone available for region $region."
    cleanup
    exit 1
fi

# create new instance
debug "Creating new instance ${ami_ids[$region]} in region $region on AWS."
output=$(ec2-run-instances ${ami_ids[$region]} $EC2_BACKUP_FLAGS_AWS -t t1.micro -z $availability_zone)

check_for_failure "Unable to create instance on AWS."

instance_id=$(echo $output | grep -o "INSTANCE.*" | awk '{print $2}')
debug "Created new instance $instance_id."

# wait until volume is ready
while [ $(ec2-describe-volumes --region $region | grep $volume_id | awk '{print $5}') != "available" ]
do
    debug "Waiting for volume to become available."
done


# wait until instance is ready
while [ $(ec2-describe-instances --region $region | grep $instance_id | awk '{print $6}') != "running" ]
do
    debug "Waiting for instance to become available."
done

# get instance host
instance_host=$(ec2-describe-instances --region $region | grep $instance_id | awk '{print $4}')

#-----------at this point both the instance and volume are ready----------------

# attach the volume to the instance
debug "Attaching volume $volume_id to instance $instance_id on $backup_device."
ec2-attach-volume $volume_id --i $instance_id --device $backup_device
check_for_failure "Unable to attach volume to instance."

#TODO: wait till volume attached

wait_for_ssh


# check if we can ssh
# debug "Checking if can ssh into AWS instance."
# ssh -o PasswordAuthentication=no -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host 'uname' > /dev/null
# if [ "$?" != 0 ]; then
#     cleanup
#     echo "Unable to ssh into instance. Please ensure your EC2_BACKUP_FLAGS_SSH variable is "\
#     "configured correctly. i.e. export EC2_BACKUP_FLAGS_SSH=/home/$USER/.ssh/aws.pem"
#     exit 1
# fi

# sleep 5
ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "echo"
check_for_failure "Failed to ssh into AWS instance. Please check your EC2_BACKUP_FLAGS_SSH environment variable."

#ssh into instance and perform backup
if [ $method == "dd" ]; then
    debug "Backing up using dd method."
    # tar + dd
    # tar -cz $dir | ssh -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "tar xzO | dd of=$backup_device"
    tar -cf - $dir | ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "sudo dd of=$backup_device bs=64k conv=block"
    check_for_failure "Failed to backup."
fi

if [ $method == "rsync" ]; then
    debug "Backing up using rsync method"
    ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "sudo apt-get -y install rsync"
    check_for_failure "Failed to install rsync on AWS instance."
    ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "sudo mkdir -p /mnt/ec2-backup"
    check_for_failure "Failed to create mount directory on AWS instance."
    ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "echo -e 'n\np\n1\n\n\nw\n' | sudo fdisk $backup_device"
    check_for_failure "Failed to create partition on AWS volume."
    ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "sudo mkfs -t ext4 $backup_partition"
    check_for_failure "Failed to create filesystem on AWS volume partition."
    ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH $ami_user@$instance_host "sudo mount $backup_partition /mnt/ec2-backup && sudo chown -R $ami_user /mnt/ec2-backup"
    check_for_failure "Failed to mount AWS volume partition and change permissions of mount directory."
    rsync -e "ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $EC2_BACKUP_FLAGS_SSH" -avz -vv --rsync-path="sudo rsync" $dir "$ami_user@$instance_host:/mnt/ec2-backup"
    check_for_failure "Failed to backup."
fi


cleanup false   # don't delete volume
echo $volume_id

exit 0
