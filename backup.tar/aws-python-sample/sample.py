import boto
import boto.ec2

ec2 = boto.connect_ec2()
key_pair = ec2.create_key_pair('key_backup')  # only needs to be done once
key_pair.save('./test')
reservation = ec2.run_instances(image_id='ami-bb709dd2', key_name='ec2-sample-key')

# Wait a minute or two while it boots
for r in ec2.get_all_instances():
    if r.id == reservation.id:
        break
print r.instances[0].public_dns_name  # output: ec2-184-73-24-97.compute-1.amazonaws.com


